def bopper():
    print("snazzy balls")
